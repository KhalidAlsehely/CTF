#!/bin/bash
# Check something
# TODO: Real hint hidden here