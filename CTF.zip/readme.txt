Welcome to the second Advanced File Handling Challenge!
Find and decode the secrets hidden inside.